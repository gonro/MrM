# -*- coding: utf-8 -*-  
# ============================================================
# PROJECTILE.PY  v2.0
# FIX: rotación acumulativa — se guardaba self.image rotada y se
#      volvía a rotar → imagen crecía exponencialmente cada frame.
#      Solución: _base_image fija, rotar siempre desde el original.
# ============================================================
import pygame
from settings import *


class FloatingText(pygame.sprite.Sprite):
    """Texto flotante de daño que sube y desaparece."""

    def __init__(self, x: int, y: int, text: str, color=(255, 80, 80)):
        super().__init__()
        font = pygame.font.SysFont("monospace", 20, bold=True)
        self.image = font.render(text, True, color)
        self.rect  = self.image.get_rect(center=(x, y))
        self.vel_y    = -2.0
        self.lifetime = 55

    def update(self):
        self.rect.y  += int(self.vel_y)
        self.vel_y   *= 0.92
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.kill()


class Projectile(pygame.sprite.Sprite):
    """
    Proyectil en arco parabólico.
    BUG FIX: _base_image es inmutable. Cada frame se rota desde ella.
    Antes: rotate(rotate(rotate(img))) → imagen crecía hasta ocupar
    cientos de px y las colisiones fallaban.
    """

    WIDTH  = 18
    HEIGHT = 14

    def __init__(self, x: int, y: int, direction: int):
        super().__init__()
        self.direction = direction

        # Imagen base — NUNCA se modifica
        base = pygame.Surface((self.WIDTH, self.HEIGHT), pygame.SRCALPHA)
        pts  = [
            (self.WIDTH // 2, 0),
            (self.WIDTH,      self.HEIGHT // 2),
            (self.WIDTH // 2, self.HEIGHT),
            (0,               self.HEIGHT // 2),
        ]
        pygame.draw.polygon(base, PROJ_COL, pts)
        pygame.draw.polygon(base, (200, 160, 0), pts, 2)
        self._base_image = base          # ← fuente de verdad para rotación

        self.image = self._base_image.copy()
        self.rect  = self.image.get_rect(center=(x, y))

        self.vel_x = PROJ_SPEED_X * direction
        self.vel_y = PROJ_SPEED_Y

        self.pos_x = float(x)
        self.pos_y = float(y)
        self.angle = 0.0

    def update(self):
        self.vel_y += PROJ_GRAVITY
        self.pos_x += self.vel_x
        self.pos_y += self.vel_y

        # FIX: rotar desde _base_image (tamaño siempre 18×14)
        self.angle -= 9 * self.direction
        self.image  = pygame.transform.rotate(self._base_image, self.angle)
        self.rect   = self.image.get_rect(
            center=(int(self.pos_x), int(self.pos_y))
        )

        if (self.rect.right  < -50 or
                self.rect.left  > WORLD_WIDTH + 50 or
                self.rect.top   > SCREEN_HEIGHT + 50):
            self.kill()
