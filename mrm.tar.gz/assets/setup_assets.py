# -*- coding: utf-8 -*-  
# ============================================================
# setup_assets.py
# Ejecutar UNA VEZ desde la carpeta del juego:
#   python setup_assets.py
#
# Requiere: pip install pillow
# Lee los .jfif originales y genera los PNG con fondo removido
# ============================================================
import os
import sys

try:
    from PIL import Image
    import numpy as np
except ImportError:
    print("Instalando Pillow...")
    os.system(f"{sys.executable} -m pip install pillow numpy")
    from PIL import Image
    import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))

# Carpetas de destino
SPRITE_DIR = os.path.join(BASE, "assets", "sprites")
BG_DIR     = os.path.join(BASE, "assets", "backgrounds")
os.makedirs(SPRITE_DIR, exist_ok=True)
os.makedirs(BG_DIR,     exist_ok=True)

# ----------------------------------------------------------------
# HELPERS
# ----------------------------------------------------------------
def remove_teal(img_rgb):
    """Remueve fondo turquesa/cyan (fondo del player pj.jfif)."""
    arr = np.array(img_rgb).astype(int)
    r, g, b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
    # Turquesa: G mucho mayor que R, B mayor que R
    mask = (g > r + 55) & (b > r + 35) & (g > 130) & (b > 120)
    rgba = np.zeros((*arr.shape[:2], 4), dtype=np.uint8)
    rgba[:,:,:3] = arr
    rgba[:,:,3]  = np.where(mask, 0, 255)
    return Image.fromarray(rgba, 'RGBA')

def remove_checker(img_rgb, tolerance=28):
    """Remueve checker gris (fondo de enemy/boss)."""
    arr = np.array(img_rgb).astype(int)
    r, g, b = arr[:,:,0], arr[:,:,1], arr[:,:,2]
    max_diff   = np.maximum(np.abs(r-g), np.maximum(np.abs(g-b), np.abs(r-b)))
    is_gray    = max_diff < tolerance
    brightness = (r.astype(float) + g + b) / 3
    in_range   = (brightness > 95) & (brightness < 228)
    mask       = is_gray & in_range
    rgba = np.zeros((*arr.shape[:2], 4), dtype=np.uint8)
    rgba[:,:,:3] = arr
    rgba[:,:,3]  = np.where(mask, 0, 255)
    return Image.fromarray(rgba, 'RGBA')

def process(src_path, dst_path, mode, scale=None):
    if not os.path.exists(src_path):
        print(f"  [SKIP] No encontrado: {src_path}")
        return False
    img = Image.open(src_path).convert('RGB')
    if mode == 'teal':
        out = remove_teal(img)
    elif mode == 'checker':
        out = remove_checker(img)
    else:
        out = img.convert('RGBA')
    if scale:
        out = out.resize(scale, Image.LANCZOS)
    out.save(dst_path)
    print(f"  [OK] {os.path.basename(dst_path)}")
    return True

# ----------------------------------------------------------------
# SPRITES
# Busca los .jfif en la misma carpeta que el script
# ----------------------------------------------------------------
print("\n=== Procesando sprites ===")

sprite_map = [
    # (archivo_fuente,    destino_png,        modo,      scale)
    ("pj.jfif",          "pj.png",           "teal",    None),
    ("enemy.jfif",       "enemy.png",        "checker", None),
    ("boss1.jfif",       "boss.png",         "checker", None),
    ("boos1-1.jfif",     "boss_sheet.png",   "checker", None),
]

for src_name, dst_name, mode, scale in sprite_map:
    src = os.path.join(BASE, src_name)
    dst = os.path.join(SPRITE_DIR, dst_name)
    process(src, dst, mode, scale)

# ----------------------------------------------------------------
# BACKGROUNDS — escalar a 1600x450 para parallax
# ----------------------------------------------------------------
print("\n=== Procesando backgrounds ===")

# Intenta con los nombres que pueden tener los archivos
bg_candidates = [
    # (posibles nombres fuente,                      destino)
    (["db06f768-c40a-481d-8ed0-354123b9eed1.jfif",
      "background_street.jfif", "bg2.jfif"],         "bg_street.png"),
    (["5dbdd9d0-a878-4b0a-8065-74a3bc801217.jfif",
      "background_tower.jfif",  "bg1.jfif"],         "bg_tower.png"),
    (["de2df17d-cd72-40cb-8cdf-684c99a7612f.jfif",
      "background_ramen.jfif",  "bg3.jfif"],         "bg_ramen.png"),
]

for candidates, dst_name in bg_candidates:
    dst = os.path.join(BG_DIR, dst_name)
    found = False
    for cand in candidates:
        src = os.path.join(BASE, cand)
        if os.path.exists(src):
            img = Image.open(src).convert('RGB')
            img = img.resize((1600, 450), Image.LANCZOS)
            img.save(dst)
            print(f"  [OK] {dst_name}  ← {cand}")
            found = True
            break
    if not found:
        print(f"  [SKIP] {dst_name}: ninguna fuente encontrada")
        print(f"         Buscados: {candidates}")

# ----------------------------------------------------------------
# RESUMEN
# ----------------------------------------------------------------
print("\n=== Resultado ===")
for d, label in [(SPRITE_DIR, "sprites"), (BG_DIR, "backgrounds")]:
    files = os.listdir(d) if os.path.exists(d) else []
    print(f"  assets/{label}/: {files}")

print("\nListo. Ahora ejecuta: python main.py")
