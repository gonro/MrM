# -*- coding: utf-8 -*-
# ============================================================
# MAIN.PY v3.1 - MR.M Corporate Chaos
# Desarrollado por ONIRAI
# CAMBIOS v3.1:
#   - Deteccion PC vs movil: botones tactiles solo en movil
#   - Fix botones tactiles: reset total en FINGERUP (no quedan pegados)
#   - Touch con multiples dedos: if en vez de elif en _handle_touch
#   - Creditos ONIRAI en pantalla intro y game over
# ============================================================
import pygame, sys, os, asyncio, traceback
from settings   import *
from camera     import Camera
from player     import Player
from level      import Level
from projectile import Projectile, FloatingText
from ui         import UI
from sprite_loader import load_background, load_image

# ============================================================
# DETECCION DE PLATAFORMA
# True  = celular / web touch
# False = PC / desktop
# ============================================================
IS_MOBILE = sys.platform == "emscripten"

_audio_started = False

def ensure_audio_started():
    global _audio_started
    if not _audio_started:
        try:
            pygame.mixer.music.set_volume(pygame.mixer.music.get_volume())
            _audio_started = True
        except:
            pass


class AudioManager:
    AUDIO_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "audio")

    def __init__(self):
        self.enabled = False
        self.sounds = {}
        self.current_music = None
        try:
            if sys.platform == "emscripten":
                pygame.mixer.pre_init(48000, -16, 2, 2048)
                pygame.mixer.init(48000, -16, 2, 2048)
            else:
                pygame.mixer.pre_init(44100, -16, 2, 1024)
                pygame.mixer.init(44100, -16, 2, 1024)
            pygame.mixer.set_num_channels(16)
            self.enabled = True
            print("[Audio] OK")
        except Exception as e:
            print(f"[Audio] {e}")
            return
        self._load_all()

    def _try_load(self, name, *fnames):
        for fn in fnames:
            p = os.path.join(self.AUDIO_DIR, fn)
            if os.path.exists(p):
                try:
                    self.sounds[name] = pygame.mixer.Sound(p)
                    print(f"[Audio] {fn}")
                    return
                except:
                    pass

    def _load_all(self):
        os.makedirs(self.AUDIO_DIR, exist_ok=True)
        self._try_load("shoot",       "shoot.ogg",      "shoot.wav")
        self._try_load("enemy_die",   "enemy_die.ogg",  "enemy_die.wav")
        self._try_load("boss_hit",    "boss_hit.ogg",   "boss_hit.wav")
        self._try_load("boss_death",  "boss_death.ogg", "boss_death.wav")
        self._try_load("jump",        "jump.ogg",       "jump.wav")
        self._try_load("checkpoint",  "checkpoint.ogg", "checkpoint.wav")
        self._try_load("celebrate",   "celebrate.ogg",  "celebrate.wav")
        self._try_load("player_hit",  "hurt.ogg",       "player_hit.wav", "hurt.wav")
        self._try_load("game_over",   "game_over.ogg",  "game_over.wav")
        self._try_load("level_start", "level_start.ogg","level_start.wav")
        self._try_load("victory",     "win.ogg",        "win.wav")

    def play(self, name, vol=1.0):
        if not self.enabled:
            return
        s = self.sounds.get(name)
        if s:
            try:
                s.set_volume(vol)
                channel = pygame.mixer.find_channel(True)
                if channel:
                    channel.play(s)
            except Exception as e:
                print(f"SFX error: {e}")

    def play_music(self, *fnames, loops=-1, volume=0.55):
        if not self.enabled:
            return
        for fn in fnames:
            p = os.path.join(self.AUDIO_DIR, fn)
            if os.path.exists(p):
                if self.current_music == fn:
                    return
                try:
                    pygame.mixer.music.load(p)
                    if sys.platform == "emscripten":
                        pygame.mixer.music.set_volume(0.4)
                    else:
                        pygame.mixer.music.set_volume(volume)
                    pygame.mixer.music.play(loops)
                    self.current_music = fn
                    print(f"[Audio] Musica: {fn}")
                    return
                except Exception as e:
                    print(f"[Audio] {fn}: {e}")

    def stop_music(self):
        if self.enabled:
            pygame.mixer.music.fadeout(800)
            self.current_music = None


class ParallaxBackground:
    def __init__(self):
        self.layers = []
        for fn, f in [("bg_street.png", 0.0), ("bg_ramen.png", 0.2), ("bg_tower.png", 0.5)]:
            try:
                s = load_background(fn)
                s = pygame.transform.scale(s, (SCREEN_WIDTH * 2, SCREEN_HEIGHT))
                self.layers.append((s, f))
            except Exception as e:
                print(f"[BG] {fn}: {e}")
        if not self.layers:
            sky = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            sky.fill(DARK_BLUE)
            self.layers.append((sky, 0.0))

    def draw(self, surface, camera):
        for surf, f in self.layers:
            ox = camera.parallax_offset(f)
            w = surf.get_width()
            if f == 0.0:
                surface.blit(surf, (0, 0))
            else:
                x = ox % w
                surface.blit(surf, (x, 0))
                surface.blit(surf, (x - w, 0))
                if x + w < SCREEN_WIDTH:
                    surface.blit(surf, (x + w, 0))


class KillText(pygame.sprite.Sprite):
    def __init__(self, x, y, text):
        super().__init__()
        font = pygame.font.SysFont("monospace", 22, bold=True)
        self.image = font.render(text, True, (255, 220, 50))
        self.rect = self.image.get_rect(center=(x, y))
        self.vel_y = -2.8
        self.life = 75

    def update(self):
        self.rect.y += int(self.vel_y)
        self.vel_y *= 0.92
        self.life -= 1
        if self.life <= 0:
            self.kill()


class IntroScreen:
    def __init__(self, screen):
        self.screen = screen
        self.done = False
        self.timer = 180
        self.font = pygame.font.SysFont("monospace", 20, bold=True)
        self.font_credit = pygame.font.SysFont("monospace", 13)
        self._logo = None
        try:
            from sprite_loader import load_image
            self._logo = load_image("logo_mrm.png", scale=(400, 180))
        except:
            pass

    def update(self, events):
        self.timer -= 1
        if self.timer <= 0:
            self.done = True
        for e in events:
            if e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN,
                          pygame.FINGERDOWN, pygame.FINGERUP):
                ensure_audio_started()
                self.done = True

    def draw(self):
        self.screen.fill((5, 8, 15))
        if self._logo:
            lx = SCREEN_WIDTH // 2 - self._logo.get_width() // 2
            ly = SCREEN_HEIGHT // 2 - self._logo.get_height() // 2 - 20
            self.screen.blit(self._logo, (lx, ly))

        # Mensaje principal -- adaptado a movil o PC
        if IS_MOBILE:
            msg = "TOCA LA PANTALLA PARA COMENZAR"
        else:
            msg = "PRESS ANY KEY TO START"

        t = self.font.render(
            msg, True,
            (255, 220, 50) if (self.timer // 15) % 2 == 0 else (180, 150, 30)
        )
        self.screen.blit(t, (SCREEN_WIDTH // 2 - t.get_width() // 2, SCREEN_HEIGHT - 70))

        # Credito ONIRAI
        credit = self.font_credit.render(
            "Desarrollado por ONIRAI", True, (80, 90, 110)
        )
        self.screen.blit(credit, (SCREEN_WIDTH // 2 - credit.get_width() // 2, SCREEN_HEIGHT - 20))


class Game:
    def __init__(self):
        if sys.platform == "emscripten":
            pygame.mixer.pre_init(48000, -16, 2, 2048)
            pygame.init()
            pygame.mixer.init(48000, -16, 2, 2048)
        else:
            pygame.mixer.pre_init(44100, -16, 2, 1024)
            pygame.init()
            pygame.mixer.init(44100, -16, 2, 1024)
        pygame.mixer.set_num_channels(16)
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()

        # Touch input -- solo se usan en IS_MOBILE
        self.touch_left  = False
        self.touch_right = False
        self.touch_jump  = False
        self.touch_shoot = False

        self.audio  = AudioManager()
        self.bg     = ParallaxBackground()
        self.camera = Camera(WORLD_WIDTH, SCREEN_WIDTH)
        self.player = Player(100, GROUND_Y, self.audio)
        self.level  = Level()
        self.ui     = UI(self.screen)

        self.projectiles = pygame.sprite.Group()
        self.kill_texts  = pygame.sprite.Group()

        self.running           = True
        self._boss_music_on    = False
        self.game_over         = False
        self.victory           = False
        self.show_intro        = True
        self.intro             = IntroScreen(self.screen)
        self.level_started     = False
        self.game_over_sounded = False
        self.waiting_for_level = False

        self.audio.play_music("level_music.ogg", "level_music.mp3")

    # ============================================================
    # RUN
    # ============================================================
    async def run(self):
        while self.running:
            raw_events = pygame.event.get()
            self._handle_events(raw_events)
            self._update(raw_events)
            self._draw()
            self.clock.tick(FPS)
            await asyncio.sleep(0)
        pygame.quit()
        sys.exit()

    # ============================================================
    # HANDLE EVENTS
    # ============================================================
    def _handle_events(self, raw_events):
        for event in raw_events:

            # -- Salir --
            if event.type == pygame.QUIT:
                self.running = False

            # -- Teclado (PC) --
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                if (self.game_over or self.victory) and event.key == pygame.K_r:
                    self._restart()
                if not self.show_intro and not self.game_over and not self.victory:
                    if event.key in (pygame.K_f, pygame.K_z, pygame.K_LCTRL):
                        self._shoot()

            # -- Touch -- solo en movil/emscripten --
            if IS_MOBILE:
                if event.type == pygame.FINGERDOWN:
                    x = event.x * SCREEN_WIDTH
                    y = event.y * SCREEN_HEIGHT
                    # Reinicio tactil en game over / victoria
                    if self.game_over or self.victory:
                        self._restart()
                        return
                    self._handle_touch(x, y, True)

                if event.type == pygame.FINGERUP:
                    # *** FIX PRINCIPAL ***
                    # Reset TOTAL al soltar el dedo, sin importar posicion.
                    # Evita que los botones queden "apretados" cuando el dedo
                    # se desliza fuera del boton antes de levantarlo.
                    self.touch_left  = False
                    self.touch_right = False
                    self.touch_jump  = False
                    self.touch_shoot = False

    # ============================================================
    # HANDLE TOUCH -- botones en zona inferior
    # Usa IF en vez de ELIF para permitir multiples dedos simultaneos
    # (izquierda + salto, derecha + disparo, etc.)
    # ============================================================
    def _handle_touch(self, x, y, pressed):
        btn_h  = SCREEN_HEIGHT // 8
        btn_w  = SCREEN_WIDTH  // 6
        btn_y  = SCREEN_HEIGHT - btn_h
        pad    = btn_w // 8

        left_rect  = pygame.Rect(pad,                            btn_y, btn_w, btn_h)
        right_rect = pygame.Rect(pad * 2 + btn_w,                btn_y, btn_w, btn_h)
        jump_rect  = pygame.Rect(SCREEN_WIDTH - pad*2 - btn_w*2, btn_y, btn_w, btn_h)
        shoot_rect = pygame.Rect(SCREEN_WIDTH - pad - btn_w,     btn_y, btn_w, btn_h)

        # IF (no ELIF) -> permite detectar multiples botones a la vez
        if left_rect.collidepoint(x, y):
            self.touch_left  = pressed
        if right_rect.collidepoint(x, y):
            self.touch_right = pressed
        if jump_rect.collidepoint(x, y):
            self.touch_jump  = pressed
        if shoot_rect.collidepoint(x, y):
            self.touch_shoot = pressed

    # ============================================================
    # SHOOT
    # ============================================================
    def _shoot(self):
        if self.player.can_shoot() and not self.player.celebrating:
            d = 1 if self.player.facing_right else -1
            proj = Projectile(self.player.rect.centerx, self.player.rect.centery - 10, d)
            self.projectiles.add(proj)
            self.audio.play("shoot", 0.8)

    # ============================================================
    # RESTART
    # ============================================================
    def _restart(self):
        self.player = Player(100, GROUND_Y, self.audio)
        self.level  = Level()
        self.projectiles.empty()
        self.kill_texts.empty()
        self.game_over         = False
        self.victory           = False
        self._boss_music_on    = False
        self.level_started     = False
        self.game_over_sounded = False
        self.waiting_for_level = False
        # Reset touch por si quedo algo apretado al momento de reiniciar
        self.touch_left  = False
        self.touch_right = False
        self.touch_jump  = False
        self.touch_shoot = False
        self.audio.play_music("level_music.ogg", "level_music.mp3")

    # ============================================================
    # UPDATE
    # ============================================================
    def _update(self, raw_events):
        if self.show_intro:
            self.intro.update(raw_events)
            if self.intro.done:
                self.show_intro = False
            return

        if not self.level_started:
            self.level_started     = True
            self.waiting_for_level = True
            self.ui.show_message("", dur=90, image=self.ui.level1_img)
            self.audio.play("level_start", 0.8)

        if self.waiting_for_level:
            if self.ui.message_timer > 0:
                return
            else:
                self.waiting_for_level = False

        if self.game_over or self.victory:
            return

        if not self.player.alive:
            if not self.game_over_sounded:
                self.game_over_sounded = True
                self.audio.play("game_over", 1.0)
            self.game_over = True
            return

        touch_input = {
            'left':  self.touch_left,
            'right': self.touch_right,
            'jump':  self.touch_jump
        }
        self.player.update(self.level.platforms, touch_input)

        if self.touch_shoot:
            self._shoot()

        self.camera.update(self.player.rect)
        self.projectiles.update()
        self.kill_texts.update()
        self._check_hits()
        events = self.level.update(self.player, self.projectiles)
        self._process_events(events)

        if self.level.boss_spawned and not self._boss_music_on:
            self._boss_music_on = True
            self.audio.play_music("boss_music.ogg", "boss_music.mp3", volume=0.75)

        if self.player.rect.top > SCREEN_HEIGHT + 60:
            sx = max(100, self.level.last_checkpoint + 50)
            self.player.rect.midbottom = (sx, GROUND_Y)
            self.player.pos_x  = float(self.player.rect.x)
            self.player.pos_y  = float(self.player.rect.y)
            self.player.vel_x  = self.player.vel_y = 0.0
            self.player.on_ground = True
            self.player.iframes   = 0

        if self.level.cleared and not self.victory and not self.game_over:
            self.victory = True
            self.audio.stop_music()
            self.audio.play("victory", 1.0)
            return

    # ============================================================
    # CHECK HITS
    # ============================================================
    def _check_hits(self):
        for enemy in list(self.level.enemies):
            if enemy.defeated:
                continue
            hits = pygame.sprite.spritecollide(enemy, self.projectiles, True)
            if not hits:
                continue
            killed = enemy.take_hit(ENEMY_DAMAGE * len(hits))
            if killed:
                self.audio.play("enemy_die", 0.9)
                self.player.celebrate_kill(enemy.rect)
                self.audio.play("celebrate", 0.75)
                self.player.add_score(SCORE_PER_KILL)
                self.kill_texts.add(KillText(
                    enemy.rect.centerx, enemy.rect.top - 20,
                    self.player.kill_text
                ))
        if self.level.boss_spawned and self.level.boss and self.level.boss.alive:
            hits = pygame.sprite.spritecollide(self.level.boss, self.projectiles, True)
            if hits:
                self.level.boss.take_hit(ENEMY_DAMAGE * len(hits))
                self.audio.play("boss_hit", 1.0)

    # ============================================================
    # PROCESS EVENTS
    # ============================================================
    def _process_events(self, events):
        for evt in events:
            t = evt['type']
            if t == 'checkpoint':
                self.ui.show_message("CHECKPOINT!", dur=90)
                self.audio.play("checkpoint", 0.9)
            elif t == 'player_hit':
                self.ui.trigger_damage_flash()
                self.audio.play("player_hit", 0.85)
            elif t == 'boss_dead':
                self.audio.stop_music()
                self.audio.play("boss_death", 1.0)
                self.player.add_score(SCORE_PER_BOSS)
                self.ui.show_message("MR. GRIMES FIRED!!", dur=240)

    # ============================================================
    # DRAW
    # ============================================================
    def _draw(self):
        self.screen.fill(DARK_BLUE)

        if self.show_intro:
            self.intro.draw()
            pygame.display.flip()
            return

        self.bg.draw(self.screen, self.camera)
        pygame.draw.rect(self.screen, (28, 33, 45),
                         (0, GROUND_Y, SCREEN_WIDTH, SCREEN_HEIGHT - GROUND_Y))
        pygame.draw.line(self.screen, (50, 60, 80),
                         (0, GROUND_Y), (SCREEN_WIDTH, GROUND_Y), 2)

        self.level.draw(self.screen, self.camera)

        if self.player.should_draw():
            img, dx, dy = self.player.get_draw_pos()
            cx, cy = self.camera.apply_pos(dx, dy)
            self.screen.blit(img, (cx, cy))

        for proj in self.projectiles:
            self.screen.blit(proj.image, self.camera.apply(proj.rect))
        for kt in self.kill_texts:
            self.screen.blit(kt.image, self.camera.apply(kt.rect))

        boss_ref = self.level.boss if self.level.boss_spawned else None
        self.ui.draw(self.player, boss=boss_ref,
                     cleared=self.level.cleared, score=self.player.score)

        if self.game_over:
            self.ui.draw_game_over(self.screen, self.player.score)
            font_r = pygame.font.SysFont("monospace", 24, bold=True)
            msg = "TOCA PARA REINICIAR" if IS_MOBILE else "R = REINICIAR"
            txt_r = font_r.render(msg, True, (255, 255, 255))
            self.screen.blit(txt_r, txt_r.get_rect(
                center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 80)))
            # Credito
            fc = pygame.font.SysFont("monospace", 11)
            cr = fc.render("Desarrollado por ONIRAI", True, (60, 70, 90))
            self.screen.blit(cr, cr.get_rect(
                center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 10)))

        elif self.victory:
            self.ui.draw_victory(self.screen, self.player.score)
            font_r = pygame.font.SysFont("monospace", 24, bold=True)
            msg = "TOCA PARA REINICIAR" if IS_MOBILE else "R = REINICIAR"
            txt_r = font_r.render(msg, True, (255, 255, 255))
            self.screen.blit(txt_r, txt_r.get_rect(
                center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 80)))

        # Debug info
        fps_s = pygame.font.SysFont("monospace", 11).render(
            f"FPS:{int(self.clock.get_fps())} "
            f"X:{self.player.rect.x} "
            f"HP:{int(self.player.hp)} "
            f"${self.player.score}",
            True, (70, 80, 100)
        )
        self.screen.blit(fps_s, (4, SCREEN_HEIGHT - 16))

        # Botones tactiles -- solo en movil
        if IS_MOBILE:
            self._draw_touch_controls()

        pygame.display.flip()

    # ============================================================
    # DRAW TOUCH CONTROLS -- solo se llama si IS_MOBILE
    # ============================================================
    def _draw_touch_controls(self):
        btn_h = SCREEN_HEIGHT // 8
        btn_w = SCREEN_WIDTH  // 6
        y     = SCREEN_HEIGHT - btn_h
        pad   = btn_w // 8

        colors = {
            "left":  (80,  80,  255, 80),
            "right": (80,  80,  255, 80),
            "jump":  (80,  255, 80,  80),
            "shoot": (255, 80,  80,  80),
        }

        rects = {
            "left":  (pad,                            y, btn_w, btn_h),
            "right": (pad * 2 + btn_w,                y, btn_w, btn_h),
            "jump":  (SCREEN_WIDTH - pad*2 - btn_w*2, y, btn_w, btn_h),
            "shoot": (SCREEN_WIDTH - pad - btn_w,     y, btn_w, btn_h),
        }

        labels = {"left": "<", "right": ">", "jump": "^", "shoot": "O"}

        for key, (x, y_pos, w, h) in rects.items():
            surf = pygame.Surface((w, h), pygame.SRCALPHA)
            surf.fill(colors[key])
            pygame.draw.rect(surf, (255, 255, 255, 150), (0, 0, w, h), 2)
            font = pygame.font.SysFont(None, min(w, h) // 2)
            txt  = font.render(labels[key], True, (255, 255, 255))
            surf.blit(txt, txt.get_rect(center=(w // 2, h // 2)))
            self.screen.blit(surf, (x, y_pos))


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":

    async def main():
        try:
            game = Game()
            await game.run()
        except Exception as e:
            print(f"ERROR CRITICO: {e}")
            traceback.print_exc()

    asyncio.run(main())