# -*- coding: utf-8 -*-  
import pygame
import os

pygame.mixer.pre_init(44100, -16, 2, 1024)
pygame.init()

audio_dir = "assets/audio"

for f in os.listdir(audio_dir):
    if f.endswith(".ogg"):
        try:
            s = pygame.mixer.Sound(os.path.join(audio_dir, f))
            print(f"✅ OK: {f}")
        except Exception as e:
            print(f"❌ ERROR: {f} — {e}")
