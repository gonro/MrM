# -*- coding: utf-8 -*-  
import zipfile
import os
import shutil

web_final = "build/web_final"
zip_path = "juego_web.zip"

# Limpiar y copiar solo los archivos necesarios desde build/web
if os.path.exists(web_final):
    shutil.rmtree(web_final)
os.makedirs(web_final, exist_ok=True)

# Copiar solo index.html, juegom.tar.gz y favicon.png
for file in ["index.html", "juegom.tar.gz", "favicon.png"]:
    src = os.path.join("build/web", file)
    dst = os.path.join(web_final, file)
    if os.path.exists(src):
        shutil.copy2(src, dst)

# Crear ZIP
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(web_final):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, web_final)
            # Ignorar timestamps problemáticos
            info = zipfile.ZipInfo(arcname)
            info.compress_type = zipfile.ZIP_DEFLATED
            with open(file_path, 'rb') as f:
                zipf.writestr(info, f.read())

print(f"ZIP creado: {zip_path}")
print(f"Tamaño: {os.path.getsize(zip_path) / 1024 / 1024:.2f} MB")
