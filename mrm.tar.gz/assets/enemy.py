# -*- coding: utf-8 -*-  
# ============================================================
# ENEMY.PY  v3.1
# - Enemy: ahora usa hoja de 6 frames horizontales (2304x320)
# - BossEnemy: sin cambios
# ============================================================
import pygame
from settings import *
from sprite_loader import load_image, cut_sheet, flip_frames
from projectile import FloatingText

ENEMY_VIS_W = 120
ENEMY_VIS_H = 100
BOSS_VIS_W  = 240
BOSS_VIS_H  = 200


def _foot_row(surf: pygame.Surface) -> int:
    """Fila Y del pixel más bajo no-negro. Llamado solo en carga."""
    w, h      = surf.get_size()
    has_alpha = bool(surf.get_flags() & pygame.SRCALPHA)
    for y in range(h - 1, -1, -1):
        for x in range(0, w, 4):
            try:
                px = surf.get_at((x, y))
                if has_alpha:
                    if px[3] > 20:
                        return y
                else:
                    if px[0] > 30 or px[1] > 30 or px[2] > 30:
                        return y
            except IndexError:
                pass
    return h - 1


# ============================================================
# ENEMY (actualizado para hoja de 6 frames horizontales)
# ============================================================
class Enemy(pygame.sprite.Sprite):
    COL_W    = 46
    COL_H    = 90
    ANIM_SPD = 7

    def __init__(self, x, y, patrol_range=ENEMY_PATROL):
        super().__init__()
        self._load_sprites()

        self.frame_idx  = 0
        self.anim_timer = 0

        self.rect = pygame.Rect(0, 0, self.COL_W, self.COL_H)
        self.rect.midbottom = (x, y)
        self.image = pygame.Surface((self.COL_W, self.COL_H), pygame.SRCALPHA)

        self.origin_x     = x
        self.patrol_range = patrol_range
        self.speed        = ENEMY_SPEED
        self.direction    = 1

        self.hp       = ENEMY_HP
        self.alive    = True
        self.defeated = False
        self.vel_y    = 0.0

        self.touch_cd    = 0
        self.TOUCH_CD    = 60

        self.float_texts    = pygame.sprite.Group()
        self._current_frame = self.walk_r[0]

    def _load_sprites(self):
        """
        Nueva carga: enemy.png tiene 6 frames horizontales (2304x320).
        Se escalan a ENEMY_VIS_W x ENEMY_VIS_H (65x88).
        """
        sheet = load_image("enemy.png")
        # Ahora son 6 frames en una sola fila (rows=1, cols=6)
        all_frames = cut_sheet(sheet, cols=6, rows=1,
                               scale=(ENEMY_VIS_W, ENEMY_VIS_H))
        # Tomamos los 6 frames completos (índices 0 a 5)
        self.walk_r = all_frames[0:6]   # 6 frames
        self.walk_l = flip_frames(self.walk_r)

        # Pre-calcular pies para alineación al suelo
        self._feet_r = [_foot_row(f) for f in self.walk_r]
        self._feet_l = self._feet_r   # espejado → misma posición Y

    def update(self, platforms, float_group, player_rect=None):
        if self.touch_cd > 0:
            self.touch_cd -= 1

        result = None
        if self.defeated:
            self._death_fall()
        else:
            self._patrol()
            self._animate()
            if (player_rect is not None
                    and self.rect.width > 1
                    and self.touch_cd == 0
                    and self.rect.colliderect(player_rect)):
                self.touch_cd = self.TOUCH_CD
                result = "touch"

        self.float_texts.update()
        for ft in list(self.float_texts):
            float_group.add(ft)
        self.float_texts.empty()
        return result

    def _patrol(self):
        self.rect.x += int(self.speed * self.direction)
        if abs(self.rect.centerx - self.origin_x) >= self.patrol_range:
            self.direction *= -1

    def _animate(self):
        frames = self.walk_r if self.direction > 0 else self.walk_l
        self.anim_timer += 1
        if self.anim_timer >= self.ANIM_SPD:
            self.anim_timer = 0
            self.frame_idx  = (self.frame_idx + 1) % len(frames)
        self._current_frame = frames[self.frame_idx]
        self.image          = self._current_frame

    def _death_fall(self):
        self.vel_y  += GRAVITY * 1.5
        self.rect.y += int(self.vel_y)
        if self.rect.top > SCREEN_HEIGHT + 50:
            self.kill()

    def get_draw_pos(self):
        img = self._current_frame
        iw, ih = img.get_size()
        feet   = self._feet_r if self.direction > 0 else self._feet_l
        foot_y = feet[self.frame_idx] if self.frame_idx < len(feet) else ih - 1
        x = self.rect.centerx - iw // 2
        y = self.rect.bottom - foot_y - 1
        return img, x, y

    def take_hit(self, damage):
        if self.defeated:
            return False
        self.hp -= damage
        ft = FloatingText(self.rect.centerx, self.rect.top - 5,
                          f"-${damage}", color=(255, 220, 0))
        self.float_texts.add(ft)
        if self.hp <= 0:
            self._die()
            return True
        return False

    def _die(self):
        self.defeated = True
        self.alive    = False
        self.vel_y    = -10
        cx, cy        = self.rect.centerx, self.rect.centery
        self.rect     = pygame.Rect(cx, cy, 1, 1)


# ============================================================
# BOSS ENEMY (sin cambios)
# ============================================================
class BossEnemy(pygame.sprite.Sprite):
    COL_W    = 110
    COL_H    = 180
    ANIM_SPD = 12

    def __init__(self, x, y):
        super().__init__()
        self._load_sprites()

        self.frame_idx    = 0
        self.anim_timer   = 0
        self.current_anim = "idle"
        self.facing_right = False

        self.rect = pygame.Rect(0, 0, self.COL_W, self.COL_H)
        self.rect.midbottom = (x, GROUND_Y)
        self.image = pygame.Surface((self.COL_W, self.COL_H), pygame.SRCALPHA)

        self.hp       = BOSS_HP
        self.max_hp   = BOSS_HP
        self.alive    = True
        self.defeated = False
        self.vel_y    = 0.0
        self.speed    = BOSS_SPEED
        self.phase    = 1

        self.last_attack = 0
        self.attack_cd   = BOSS_ATTACK_CD
        self.touch_cd    = 0
        self.TOUCH_CD    = 90

        self.float_texts    = pygame.sprite.Group()
        self._current_frame = self.anim_r["idle"][0]

    def _load_sprites(self):
        sheet  = load_image("boss_sheet.png")
        frames = cut_sheet(sheet, cols=4, rows=1,
                           scale=(BOSS_VIS_W, BOSS_VIS_H))

        boss_idle = load_image("boss.png",
                               scale=(int(BOSS_VIS_H * 1.07), BOSS_VIS_H))

        self.anim_r = {
            "idle":   [boss_idle],
            "attack": [frames[1], frames[2]],
            "hurt":   [frames[3]],
        }
        self.anim_l = {k: flip_frames(v) for k, v in self.anim_r.items()}

        self._feet_r = {
            key: [_foot_row(f) for f in flist]
            for key, flist in self.anim_r.items()
        }

    def update(self, player_rect, float_group):
        if self.defeated:
            self._death_fall()
            return None

        if self.touch_cd > 0:
            self.touch_cd -= 1

        if self.hp < self.max_hp * 0.5 and self.phase == 1:
            self.phase     = 2
            self.speed    *= 1.5
            self.attack_cd = int(self.attack_cd * 0.55)

        dist = player_rect.centerx - self.rect.centerx
        self.facing_right = dist > 0
        if abs(dist) > 5:
            self.rect.x += int(self.speed) * (1 if dist > 0 else -1)

        self.rect.bottom = GROUND_Y
        self.rect.left   = max(0, self.rect.left)
        self.rect.right  = min(WORLD_WIDTH, self.rect.right)

        now = pygame.time.get_ticks()
        if now - self.last_attack >= self.attack_cd:
            self.current_anim = "attack"
            self.frame_idx    = 0
            self.last_attack  = now

        self._animate()

        self.float_texts.update()
        for ft in list(self.float_texts):
            float_group.add(ft)
        self.float_texts.empty()

        if (self.rect.width > 1
                and self.touch_cd == 0
                and self.rect.colliderect(player_rect)):
            self.touch_cd = self.TOUCH_CD
            return "touch"
        return None

    def _animate(self):
        aset   = self.anim_r if self.facing_right else self.anim_l
        frames = aset.get(self.current_anim, aset["idle"])
        self.anim_timer += 1
        if self.anim_timer >= self.ANIM_SPD:
            self.anim_timer = 0
            self.frame_idx += 1
            if self.frame_idx >= len(frames):
                self.frame_idx    = 0
                self.current_anim = "idle"
        if self.frame_idx >= len(frames):
            self.frame_idx = 0
        self._current_frame = frames[self.frame_idx]
        self.image          = self._current_frame

    def _death_fall(self):
        self.vel_y  += GRAVITY * 1.2
        self.rect.y += int(self.vel_y)
        if self.rect.top > SCREEN_HEIGHT + 80:
            self.kill()

    def get_draw_pos(self):
        img    = self._current_frame
        iw, ih = img.get_size()
        feet_list = self._feet_r.get(self.current_anim,
                                     self._feet_r["idle"])
        idx    = min(self.frame_idx, len(feet_list) - 1)
        foot_y = feet_list[idx]
        x = self.rect.centerx - iw // 2
        y = self.rect.bottom - foot_y - 1
        return img, x, y

    def take_hit(self, damage):
        if self.defeated:
            return
        self.hp -= damage
        self.current_anim = "hurt"
        self.frame_idx    = 0
        ft = FloatingText(self.rect.centerx, self.rect.top - 10,
                          f"-${damage}", color=(255, 100, 0))
        self.float_texts.add(ft)
        if self.hp <= 0:
            self.hp = 0
            self._die()

    def _die(self):
        self.defeated = True
        self.alive    = False
        self.vel_y    = -14
        cx, cy        = self.rect.centerx, self.rect.centery
        self.rect     = pygame.Rect(cx, cy, 1, 1)