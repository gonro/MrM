# ============================================================
# SPRITE_LOADER.PY — Fix vibración: NO trim individual de frames
# El problema era que cada frame tenía tamaño distinto tras el trim
# causando que el rect "vibre" al cambiar de frame.
# Solución: todos los frames del mismo sheet tienen el mismo tamaño.
# ============================================================
import pygame, os

ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "sprites")
BG_DIR    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "backgrounds")

def load_image(filename, scale=None):
    path = os.path.join(ASSET_DIR, filename)
    img  = pygame.image.load(path).convert_alpha()
    if scale:
        img = pygame.transform.scale(img, scale)
    return img

def load_background(filename):
    path = os.path.join(BG_DIR, filename)
    return pygame.image.load(path).convert()

def cut_sheet(surface, cols, rows, scale=None, padding=0):
    """
    Divide sprite sheet en celdas uniformes.
    Todos los frames quedan del mismo tamaño (sin trim individual)
    para evitar la vibración al cambiar de frame.
    Retorna lista plana: [r0c0, r0c1, ..., rNcM]
    padding: espaciado horizontal entre frames
    """
    sw, sh = surface.get_size()
    fw = (sw - padding * (cols - 1)) // cols
    fh = sh // rows
    frames = []
    for row in range(rows):
        for col in range(cols):
            x = col * (fw + padding)
            y = row * fh
            rect  = pygame.Rect(x, y, fw, fh)
            frame = surface.subsurface(rect).copy()
            if scale:
                frame = pygame.transform.scale(frame, scale)
            frames.append(frame)
    return frames

def flip_frames(frames):
    return [pygame.transform.flip(f, True, False) for f in frames]
