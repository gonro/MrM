# -*- coding: utf-8 -*-  
# ============================================================
# CAMERA.PY — Sistema de cámara con parallax
# ============================================================
import pygame
from settings import *


class Camera:
    """
    Cámara que sigue al jugador horizontalmente con interpolación suave.
    Proporciona offset para renderizar todos los sprites en la posición correcta.
    """

    def __init__(self, world_width: int, screen_width: int):
        self.offset_x = 0.0          # Posición actual de la cámara (float para suavidad)
        self.target_x = 0.0          # Posición objetivo
        self.world_width = world_width
        self.screen_width = screen_width

    # ----------------------------------------------------------
    # UPDATE: interpola hacia el jugador
    # ----------------------------------------------------------
    def update(self, target_rect: pygame.Rect):
        # Queremos centrar al jugador horizontalmente
        desired = target_rect.centerx - self.screen_width // 2

        # Interpolación suave (lerp)
        self.target_x = desired
        self.offset_x += (self.target_x - self.offset_x) * (1 - CAM_SMOOTHING)

        # Clamp: no salir del mundo
        self.offset_x = max(0, min(self.offset_x, self.world_width - self.screen_width))

    # ----------------------------------------------------------
    # APPLY: devuelve el Rect de un sprite ajustado a la cámara
    # ----------------------------------------------------------
    def apply(self, rect: pygame.Rect) -> pygame.Rect:
        return rect.move(-int(self.offset_x), 0)

    def apply_pos(self, x: float, y: float):
        """Aplica offset a una posición (x, y) suelta."""
        return x - int(self.offset_x), y

    # ----------------------------------------------------------
    # PARALLAX: devuelve el offset para cada capa de fondo
    # El factor 0.0 = quieto, 1.0 = se mueve al 100% con el mundo
    # ----------------------------------------------------------
    def parallax_offset(self, factor: float) -> int:
        return -int(self.offset_x * factor)
