# ============================================================
# SETTINGS.PY — Corporate Chaos / MR.M
# ============================================================
import pygame

SCREEN_WIDTH  = 800
SCREEN_HEIGHT = 450
FPS           = 60
TITLE         = "MR. M — Corporate Chaos"
WORLD_WIDTH   = 3000
GROUND_Y      = SCREEN_HEIGHT - 60

# Colores
BLACK        = (0,   0,   0)
WHITE        = (255, 255, 255)
DARK_BLUE    = (10,  14,  26)
GROUND_COL   = (50,  55,  70)
PLATFORM_COL = (70,  80, 100)
PROJ_COL     = (255, 200, 50)  # Color del proyectil

# Física jugador
PLAYER_ACCEL      = 0.85
PLAYER_FRICTION   = -0.15
PLAYER_MAX_SPEED  = 6
PLAYER_JUMP_FORCE = -14
GRAVITY           = 0.65
GRAVITY_FALL_MULT = 1.6

# HP y daño jugador
PLAYER_MAX_HP    = 100
PLAYER_IFRAMES   = 60   # frames invencible tras recibir daño

# Proyectiles
PROJ_SPEED_X  = 9
PROJ_SPEED_Y  = -10
PROJ_GRAVITY  = 0.5
PROJ_COOLDOWN = 350

# Enemigos
ENEMY_HP           = 100
ENEMY_SPEED        = 1.8
ENEMY_DAMAGE       = 35
ENEMY_PATROL       = 120
ENEMY_TOUCH_DAMAGE = 15

# Boss
BOSS_HP           = 999
BOSS_SPEED        = 2.8
BOSS_TRACK_DIST   = 500
BOSS_ATTACK_CD    = 2000
BOSS_TOUCH_DAMAGE = 25

# Score
SCORE_PER_KILL = 100
SCORE_PER_BOSS = 1000

# Cámara
CAM_SMOOTHING = 0.1

# UI
UI_FONT_SIZE_BIG   = 28
UI_FONT_SIZE_SMALL = 16
HP_BAR_W = 200
HP_BAR_H = 16
