# ============================================================
# LEVEL.PY — Sistema de eventos, plataformas con dos texturas (suelo y bloques)
# ============================================================
import pygame
from settings import *
from enemy import Enemy, BossEnemy
from sprite_loader import load_image


class FloatingDmg(pygame.sprite.Sprite):
    def __init__(self, x, y, text, color=(255, 80, 80)):
        super().__init__()
        font = pygame.font.SysFont("monospace", 20, bold=True)
        self.image = font.render(text, True, color)
        self.rect = self.image.get_rect(center=(x, y))
        self.vel_y = -2.2
        self.life = 55
    def update(self):
        self.rect.y += int(self.vel_y)
        self.vel_y *= 0.91
        self.life -= 1
        if self.life <= 0:
            self.kill()


class Platform(pygame.sprite.Sprite):
    """Plataforma con textura específica (suelo o bloque) escalada al tamaño dado."""
    def __init__(self, x, y, width, height, texture_name):
        super().__init__()
        # Cargar la textura base (cache por nombre)
        cache_attr = f"_texture_{texture_name.replace('.','_')}"
        if not hasattr(Platform, cache_attr):
            try:
                texture = load_image(texture_name)
                setattr(Platform, cache_attr, texture)
                print(f"[Level] Textura {texture_name} cargada")
            except Exception as e:
                print(f"[Level] Error cargando {texture_name}: {e}")
                # Fallback: superficie de color
                fallback = pygame.Surface((width, height))
                fallback.fill(PLATFORM_COL if texture_name == "bloque.png" else GROUND_COL)
                setattr(Platform, cache_attr, fallback)
        base = getattr(Platform, cache_attr)
        # Escalar al tamaño exacto
        self.image = pygame.transform.scale(base, (width, height))
        self.rect = self.image.get_rect(topleft=(x, y))


class Level:
    def __init__(self):
        self.platforms   = pygame.sprite.Group()
        self.enemies     = pygame.sprite.Group()
        self.boss_group  = pygame.sprite.Group()
        self.float_texts = pygame.sprite.Group()
        self.boss = None
        self.boss_spawned = False
        self.cleared      = False
        self.checkpoints  = [700, 1400, 2100]
        self.last_checkpoint = 0
        self._build()

    def _build(self):
        gnd = GROUND_Y

        # SUELO (usa textura piso.png)
        for sx, sw in [(0, 600), (700, 500), (1300, 400), (1800, 300), (2200, 800)]:
            self.platforms.add(Platform(sx, gnd, sw, 60, "piso.png"))

        # PLATAFORMAS FLOTANTES (usa textura bloque.png)
        for px, py, pw in [
            (200, 280, 120), (420, 220, 100), (560, 170, 80), (800, 260, 140),
            (1000, 190, 100), (1150, 280, 120), (1400, 200, 90), (1600, 250, 110),
            (1900, 180, 100), (2050, 260, 80), (2300, 240, 130), (2500, 200, 100),
            (2700, 280, 120)
        ]:
            self.platforms.add(Platform(px, py, pw, 20, "bloque.png"))

        # Enemigos comunes
        for sp in [400, 900, 1100, 1350, 1700, 2000, 2300, 2600]:
            self.enemies.add(Enemy(sp, gnd))

        # Jefe final
        self.boss = BossEnemy(2750, gnd)

    def update(self, player, projectiles):
        # ... (el resto del método update es idéntico al que ya tenías) ...
        events = []
        player_rect = player.rect

        for enemy in list(self.enemies):
            try:
                result = enemy.update(self.platforms, self.float_texts, player_rect)
                if result == "touch":
                    hit = player.take_damage(ENEMY_TOUCH_DAMAGE)
                    if hit:
                        events.append({'type': 'player_hit'})
                        ft = FloatingDmg(player_rect.centerx, player_rect.top - 10,
                                         f"-${ENEMY_TOUCH_DAMAGE}", (255, 80, 80))
                        self.float_texts.add(ft)
            except Exception as e:
                print(f"[Enemy err] {e}")

        if not self.boss_spawned and player_rect.x > 2500:
            self.boss_group.add(self.boss)
            self.boss_spawned = True

        if self.boss_spawned and self.boss and self.boss.alive:
            try:
                result = self.boss.update(player_rect, self.float_texts)
                if result == "touch":
                    hit = player.take_damage(BOSS_TOUCH_DAMAGE)
                    if hit:
                        events.append({'type': 'player_hit'})
                        ft = FloatingDmg(player_rect.centerx, player_rect.top - 10,
                                         f"-${BOSS_TOUCH_DAMAGE}", (255, 60, 0))
                        self.float_texts.add(ft)
            except Exception as e:
                print(f"[Boss err] {e}")

        if self.boss_spawned and self.boss and not self.boss.alive and not self.cleared:
            self.cleared = True
            events.append({'type': 'boss_dead'})

        self.float_texts.update()

        for cp in self.checkpoints:
            if player_rect.x > cp and self.last_checkpoint < cp:
                self.last_checkpoint = cp
                events.append({'type': 'checkpoint'})

        return events

    def draw(self, surface, camera):
        # Dibujar plataformas
        for p in self.platforms:
            surface.blit(p.image, camera.apply(p.rect))

        # Enemigos comunes
        for e in self.enemies:
            if hasattr(e, 'get_draw_pos') and hasattr(e, '_current_frame'):
                try:
                    img, dx, dy = e.get_draw_pos()
                    surface.blit(img, camera.apply_pos(dx, dy))
                except:
                    pass

        # Jefe
        if self.boss_spawned:
            for b in self.boss_group:
                if hasattr(b, 'get_draw_pos') and hasattr(b, '_current_frame'):
                    try:
                        img, dx, dy = b.get_draw_pos()
                        surface.blit(img, camera.apply_pos(dx, dy))
                    except:
                        pass

        # Textos flotantes
        for ft in self.float_texts:
            surface.blit(ft.image, camera.apply(ft.rect))

        # Checkpoints (líneas doradas)
        for cp in self.checkpoints:
            if cp > self.last_checkpoint:
                rx, ry = camera.apply_pos(cp - 4, GROUND_Y - 44)
                pygame.draw.rect(surface, (255, 200, 0), (rx, ry, 8, 44))