# ============================================================
# UI.PY — HUD con score, texto pixel art, logo, damage flash
# ============================================================
import pygame, os
from settings import *
from sprite_loader import load_image

class UI:
    def __init__(self, screen):
        self.screen = screen
        self.font_big   = pygame.font.SysFont("monospace", UI_FONT_SIZE_BIG,   bold=True)
        self.font_small = pygame.font.SysFont("monospace", UI_FONT_SIZE_SMALL, bold=True)
        self.font_score = pygame.font.SysFont("monospace", 18, bold=True)

        # Fuente Arcade para mensajes de victoria
        try:
            self.font_arcade = pygame.font.Font(os.path.join("assets", "fonts", "ArcadeClassic.ttf"), 20)
        except:
            self.font_arcade = self.font_big  # fallback

        self.message       = ""
        self.message_image = None
        self.message_timer = 0
        self.damage_flash  = 0

        # Logo MR.M pequeño para el HUD
        self._logo = None
        try:
            self._logo = load_image("logo_mrm.png", scale=(80, 36))
        except: pass

        # Textos pixel art pre-cargados
        self._texts = {}
        for name in ['game_over','start','exit','ajuste','cucatira']:
            try:
                self._texts[name] = load_image(f"text_{name}.png")
            except: pass

        # Imagen LEVEL 1 (escalada)
        self.level1_img = None
        try:
            raw = load_image("level1.png")
            max_width = SCREEN_WIDTH - 100
            scale = max_width / raw.get_width()
            new_w = int(raw.get_width() * scale)
            new_h = int(raw.get_height() * scale)
            self.level1_img = pygame.transform.scale(raw, (new_w, new_h))
        except: pass

        # Imagen YOU WIN! (se escala a 200x200 para que no ocupe toda la pantalla)
        self.win_img = None
        try:
            raw = load_image("youwin.png")
            target_size = 200  # píxeles de ancho (alto proporcional)
            scale = target_size / raw.get_width()
            new_w = target_size
            new_h = int(raw.get_height() * scale)
            self.win_img = pygame.transform.scale(raw, (new_w, new_h))
            print(f"[UI] youwin.png escalada a {new_w}x{new_h}")
        except Exception as e:
            print(f"[UI] No se pudo cargar youwin.png: {e}")

    def draw(self, player, boss=None, cleared=False, score=0):
        if self.damage_flash > 0:
            flash = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            flash.fill((220, 0, 0, min(120, self.damage_flash * 8)))
            self.screen.blit(flash, (0,0))
            self.damage_flash -= 1

        self._draw_hp(player)
        self._draw_score(score)
        if self._logo:
            self.screen.blit(self._logo, (SCREEN_WIDTH - 88, 6))
        if boss and boss.alive:
            self._draw_boss_bar(boss)
        if cleared:
            self._draw_cleared()
        if self.message_timer > 0:
            self._draw_message()
            self.message_timer -= 1

    def trigger_damage_flash(self):
        self.damage_flash = 15

    def _draw_hp(self, player):
        panel = pygame.Surface((HP_BAR_W + 60, 44), pygame.SRCALPHA)
        panel.fill((0,0,0,150))
        self.screen.blit(panel, (8,8))
        dollar = self.font_big.render("$", True, (255,220,0))
        self.screen.blit(dollar, (14,14))
        ratio = max(0.0, player.hp / PLAYER_MAX_HP)
        col = (40,200,80) if ratio > 0.5 else (230,180,0) if ratio > 0.25 else (220,40,40)
        pygame.draw.rect(self.screen, (60,0,0),     (38,20,HP_BAR_W,HP_BAR_H))
        pygame.draw.rect(self.screen, col,           (38,20,int(HP_BAR_W*ratio),HP_BAR_H))
        pygame.draw.rect(self.screen, (180,180,180), (38,20,HP_BAR_W,HP_BAR_H),1)
        txt = self.font_small.render(f"${int(player.hp)}", True, (240,240,240))
        self.screen.blit(txt, (42,21))

    def _draw_score(self, score):
        s = self.font_score.render(f"SCORE: ${score:,}", True, (255,220,50))
        self.screen.blit(s, (SCREEN_WIDTH//2 - s.get_width()//2, 8))

    def _draw_boss_bar(self, boss):
        BAR_W = 400; BAR_H = 24
        bx = SCREEN_WIDTH//2 - BAR_W//2; by = SCREEN_HEIGHT - 55
        bg = pygame.Surface((BAR_W+24,54), pygame.SRCALPHA)
        bg.fill((0,0,0,165))
        self.screen.blit(bg, (bx-12, by-8))
        ph = "  !! PHASE 2 !!" if boss.phase == 2 else ""
        nc = (255,80,30) if boss.phase==2 else (255,160,30)
        self.screen.blit(self.font_small.render(f"MR. GRIMES{ph}",True,nc),(bx,by-4))
        ratio = max(0.0, boss.hp/boss.max_hp)
        bc = (255,40,40) if boss.phase==2 else (220,60,20)
        pygame.draw.rect(self.screen, (80,0,0),     (bx,by+14,BAR_W,BAR_H))
        pygame.draw.rect(self.screen, bc,            (bx,by+14,int(BAR_W*ratio),BAR_H))
        pygame.draw.rect(self.screen, (200,200,200), (bx,by+14,BAR_W,BAR_H),1)
        hp_t = self.font_small.render(f"${boss.hp}/{boss.max_hp}",True,(240,240,240))
        self.screen.blit(hp_t,(bx+BAR_W//2-hp_t.get_width()//2,by+16))

    def _draw_cleared(self):
        ov = pygame.Surface((SCREEN_WIDTH,SCREEN_HEIGHT),pygame.SRCALPHA)
        ov.fill((0,0,0,130)); self.screen.blit(ov,(0,0))
        t1 = self.font_big.render("LEVEL CLEARED!", True, (255,220,0))
        t2 = self.font_small.render("MR. GRIMES FIRED!", True, (200,200,200))
        self.screen.blit(t1,(SCREEN_WIDTH//2-t1.get_width()//2,SCREEN_HEIGHT//2-30))
        self.screen.blit(t2,(SCREEN_WIDTH//2-t2.get_width()//2,SCREEN_HEIGHT//2+20))

    def show_message(self, text, dur=120, image=None):
        self.message = text
        self.message_image = image
        self.message_timer = dur

    def _draw_message(self):
        if self.message_timer <= 0:
            return
        alpha = min(255, self.message_timer * 5)
        if self.message_image:
            surf = self.message_image.copy()
            surf.set_alpha(alpha)
            x = SCREEN_WIDTH // 2 - surf.get_width() // 2
            y = 80
            self.screen.blit(surf, (x, y))
        else:
            txt = self.font_big.render(self.message, True, (255,220,0))
            surf = pygame.Surface(txt.get_size(), pygame.SRCALPHA)
            surf.blit(txt, (0,0))
            surf.set_alpha(alpha)
            self.screen.blit(surf, (SCREEN_WIDTH//2 - surf.get_width()//2, 80))

    def draw_game_over(self, screen, score):
        ov = pygame.Surface((SCREEN_WIDTH,SCREEN_HEIGHT),pygame.SRCALPHA)
        ov.fill((0,0,0,200)); screen.blit(ov,(0,0))
        go = self._texts.get('game_over')
        if go:
            go_scaled = pygame.transform.scale(go, (min(go.get_width(), 500),
                                                     min(go.get_height(), 120)))
            screen.blit(go_scaled,(SCREEN_WIDTH//2-go_scaled.get_width()//2,
                                   SCREEN_HEIGHT//2-80))
        else:
            t = self.font_big.render("GAME OVER",True,(255,50,50))
            screen.blit(t,(SCREEN_WIDTH//2-t.get_width()//2,SCREEN_HEIGHT//2-60))
        sc = self.font_small.render(f"FINAL SCORE: ${score:,}",True,(255,220,50))
        screen.blit(sc,(SCREEN_WIDTH//2-sc.get_width()//2,SCREEN_HEIGHT//2+20))
        rs = self.font_small.render("R = RESTART",True,(200,200,200))
        screen.blit(rs,(SCREEN_WIDTH//2-rs.get_width()//2,SCREEN_HEIGHT//2+55))

    def draw_victory(self, screen, score):
        """Pantalla de victoria con imagen, texto Arcade y puntuación visible."""
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 220))
        screen.blit(overlay, (0, 0))

        # Imagen "YOU WIN!" escalada (200x200 aproximadamente)
        if self.win_img:
            img_rect = self.win_img.get_rect(center=(SCREEN_WIDTH//2, 120))
            screen.blit(self.win_img, img_rect)
            text_start_y = img_rect.bottom + 20
        else:
            text_start_y = 100

        # Texto de felicitaciones con fuente arcade (tamaño 18 para que entre mejor)
        message = ("Enorabuena! superaste  el  primer  nivel\n"
                   "ahora  Argentina  esta  mas  ajustada  gracias a  vos\n\n"
                   "En  los  proximos  niveles  preparate\n"
                   "por  que la  vas  a  pasar  mal!!!")
        lines = message.split('\n')
        y_offset = text_start_y
        # Usar una fuente más pequeña para el texto largo (18)
        try:
            small_arcade = pygame.font.Font(os.path.join("assets", "fonts", "ArcadeClassic.ttf"), 18)
        except:
            small_arcade = self.font_small
        for line in lines:
            text_surf = small_arcade.render(line, True, (255, 220, 100))
            text_rect = text_surf.get_rect(center=(SCREEN_WIDTH//2, y_offset))
            screen.blit(text_surf, text_rect)
            y_offset += 24

        # Puntuación final (más abajo)
        score_y = y_offset + 30
        score_text = self.font_big.render(f"FINAL SCORE: ${score:,}", True, (255, 220, 50))
        screen.blit(score_text, (SCREEN_WIDTH//2 - score_text.get_width()//2, score_y))

        # Instrucción reinicio
        restart_y = score_y + 50
        restart_text = self.font_small.render("R = RESTART", True, (200, 200, 200))
        screen.blit(restart_text, (SCREEN_WIDTH//2 - restart_text.get_width()//2, restart_y))