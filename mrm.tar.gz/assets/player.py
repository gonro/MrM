# ============================================================
# PLAYER.PY FINAL (CORREGIDO + DISPARO QUIETO + FESTEJO PROPORCIONAL)
# SOLO ARREGLOS: caída en pozos inmediata y no quedarse pegado al saltar
#
# ARCHIVOS:
#
# pj0.png        -> 1 sola imagen 384x320 (quieto)
# pjmove.png     -> 6 frames horizontales de 384x320 (usa frames 1 a 5)
# pjfest.png     -> 1 sola imagen 384x460 (festejo, más alto)
# quietoa.png    -> 1 sola imagen 384x320 (disparo quieto)
#
# ============================================================

import pygame
import random

from settings import *
from sprite_loader import load_image

KILL_PHRASES = [
    "FIRED!", "GET OUT!", "ADIOS!", "LATER!",
    "BYE BYE!", "DELETED!", "RENUNCIA!", "CHAU!",
]

# ============================================================
# CONFIG
# ============================================================

FRAME_W = 384
FRAME_H = 320

GAME_W = 120  # Tamaño escalado para el juego
GAME_H = 100

COL_W = 46
COL_H = 90

ANIM_SPEED = 4

# ============================================================
# PLAYER
# ============================================================

class Player(pygame.sprite.Sprite):

    def __init__(self, x, y, audio=None):
        super().__init__()

        self.audio = audio

        self._load_sprites()

        self.state = "idle"
        self.facing_right = True

        self.frame_idx = 0
        self.anim_timer = 0
        self._prev_key = ""
        self.shoot_anim_timer = 0

        # ----------------------------------------------------
        # RECT COLISION
        # ----------------------------------------------------

        self.rect = pygame.Rect(0, 0, COL_W, COL_H)
        self.rect.midbottom = (x, y)

        # ----------------------------------------------------
        # FRAME ACTUAL
        # ----------------------------------------------------

        self._current_frame = self.idle_r
        self.image = self._current_frame

        # ----------------------------------------------------
        # MOVIMIENTO
        # ----------------------------------------------------

        self.pos_x = float(self.rect.x)
        self.pos_y = float(self.rect.y)

        self.vel_x = 0.0
        self.vel_y = 0.0

        self.on_ground = True
        # NOTA: ya no usamos _ground_frames, se eliminó la histéresis

        # ----------------------------------------------------
        # STATS
        # ----------------------------------------------------

        self.hp = PLAYER_MAX_HP
        self.alive = True
        self.score = 0

        self.iframes = 0
        self.last_shot = 0

        # ----------------------------------------------------
        # FESTEJO
        # ----------------------------------------------------

        self.celebrating = False
        self.celebrate_timer = 0
        self.CELEBRATE_DUR = 90

        self.kill_text = ""
        self.kill_text_timer = 0

        # ----------------------------------------------------
        # DISPARO QUIETO
        # ----------------------------------------------------

        self.SHOOT_DURATION = 6

    # ========================================================
    # LOAD SPRITES
    # ========================================================

    def _load_sprites(self):

        # ----------------------------------------------------
        # IDLE
        # ----------------------------------------------------

        idle_img = load_image("pj0.png")

        self.idle_r = pygame.transform.scale(
            idle_img,
            (GAME_W, GAME_H)
        )

        self.idle_l = pygame.transform.flip(
            self.idle_r,
            True,
            False
        )

        # ----------------------------------------------------
        # MOVE SHEET
        #
        # 6 frames horizontales
        # usamos SOLO 1..5
        # ----------------------------------------------------

        move_sheet = load_image("pjmove.png")

        move_frames_r = []

        for i in range(1, 6):
            rect = pygame.Rect(i * FRAME_W, 0, FRAME_W, FRAME_H)
            frame = move_sheet.subsurface(rect).copy()
            frame = pygame.transform.scale(frame, (GAME_W, GAME_H))
            move_frames_r.append(frame)

        move_frames_l = [pygame.transform.flip(f, True, False) for f in move_frames_r]

        # ----------------------------------------------------
        # FESTEJO (con preservación de aspecto)
        # ----------------------------------------------------

        fest_img = load_image("pjfest.png")
        fest_original_w, fest_original_h = fest_img.get_size()
        fest_scale = GAME_W / fest_original_w
        fest_new_w = GAME_W
        fest_new_h = int(fest_original_h * fest_scale)

        self.fest_r = pygame.transform.scale(fest_img, (fest_new_w, fest_new_h))
        self.fest_l = pygame.transform.flip(self.fest_r, True, False)

        # ----------------------------------------------------
        # DISPARO QUIETO
        # ----------------------------------------------------

        shoot_img = load_image("quietoa.png")
        # Escalar al mismo tamaño que los otros sprites (GAME_W x GAME_H)
        shoot_img = pygame.transform.scale(shoot_img, (GAME_W, GAME_H))

        # ----------------------------------------------------
        # ANIMACIONES
        # ----------------------------------------------------

        self.anim = {
            "run_r": move_frames_r,
            "run_l": move_frames_l,
            "jump_r": [move_frames_r[2]],
            "jump_l": [move_frames_l[2]],
            "fall_r": [move_frames_r[3]],
            "fall_l": [move_frames_l[3]],
            "moto_r": [self.fest_r],
            "moto_l": [self.fest_l],
            "shoot_r": [shoot_img],
            "shoot_l": [pygame.transform.flip(shoot_img, True, False)],
        }

    # ========================================================
    # UPDATE
    # ========================================================

    def update(self, platforms, touch_input=None):

        if self.iframes > 0:
            self.iframes -= 1

        keys = pygame.key.get_pressed()

        if self.celebrating:
            self._tick_celebrate()
            self.vel_x *= 0.75
            if abs(self.vel_x) < 0.3:
                self.vel_x = 0.0
        else:
            self._handle_input(keys, touch_input)

        self._apply_gravity()
        self._move_and_collide(platforms)   # aquí se actualiza self.on_ground

        self._update_state()
        self._animate()

        if self.kill_text_timer > 0:
            self.kill_text_timer -= 1


    # ========================================================
    # INPUT
    # ========================================================

    def _handle_input(self, keys, touch_input=None):
        # Keyboard input
        left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
        jump = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]

        # Touch input
        if touch_input:
            left = left or touch_input.get('left', False)
            right = right or touch_input.get('right', False)
            jump = jump or touch_input.get('jump', False)

        if left and not right:
            self.facing_right = False
            self.vel_x -= PLAYER_ACCEL
            if self.vel_x < -PLAYER_MAX_SPEED:
                self.vel_x = -PLAYER_MAX_SPEED
        elif right and not left:
            self.facing_right = True
            self.vel_x += PLAYER_ACCEL
            if self.vel_x > PLAYER_MAX_SPEED:
                self.vel_x = PLAYER_MAX_SPEED
        else:
            if self.on_ground:
                self.vel_x = 0.0
            else:
                self.vel_x *= 0.98

        if abs(self.vel_x) < 0.05:
            self.vel_x = 0.0

        if jump and self.on_ground:
            self.vel_y = PLAYER_JUMP_FORCE
            self.on_ground = False
            if self.audio:
                self.audio.play("jump", 1.0)

    # ========================================================
    # GRAVEDAD
    # ========================================================

    def _apply_gravity(self):
        if not self.on_ground:
            mult = GRAVITY_FALL_MULT if self.vel_y > 0 else 1.0
            self.vel_y = min(self.vel_y + GRAVITY * mult, 22)

    # ========================================================
    # MOVIMIENTO + COLISION (CORREGIDO: sin histéresis, caída inmediata)
    # ========================================================

    def _move_and_collide(self, platforms):

        # Movimiento horizontal
        self.pos_x += self.vel_x
        self.rect.x = int(self.pos_x)

        hits = pygame.sprite.spritecollide(self, platforms, False)
        for hit in hits:
            if self.vel_x > 0:
                self.rect.right = hit.rect.left
            elif self.vel_x < 0:
                self.rect.left = hit.rect.right
            self.pos_x = float(self.rect.x)
            self.vel_x = 0.0

        # Movimiento vertical
        self.pos_y += self.vel_y
        self.rect.y = int(self.pos_y)

        hits = pygame.sprite.spritecollide(self, platforms, False)
        for hit in hits:
            if self.vel_y > 0:   # cayendo
                self.rect.bottom = hit.rect.top
                self.pos_y = float(self.rect.y)
                self.vel_y = 0.0
            elif self.vel_y < 0: # subiendo (golpe cabeza)
                self.rect.top = hit.rect.bottom
                self.pos_y = float(self.rect.y)
                self.vel_y = 0.0

        # Detección de suelo REAL (sin histéresis): un rectángulo bajo los pies
        feet_rect = pygame.Rect(self.rect.left, self.rect.bottom - 1, self.rect.width, 3)
        self.on_ground = False
        for plat in platforms:
            if feet_rect.colliderect(plat.rect):
                self.on_ground = True
                break

        # Límites del mundo
        if self.rect.left < 0:
            self.rect.left = 0
            self.pos_x = 0.0
        if self.rect.right > WORLD_WIDTH:
            self.rect.right = WORLD_WIDTH
            self.pos_x = float(self.rect.x)

    # ========================================================
    # STATE
    # ========================================================

    def _update_state(self):

        if self.celebrating:
            self.state = "moto"
            return

        # Animación de disparo tiene prioridad
        if self.shoot_anim_timer > 0:
            self.state = "shoot"
            self.shoot_anim_timer -= 1
            return

        if not self.on_ground:
            if self.vel_y < 0:
                self.state = "jump"
            else:
                self.state = "fall"
            return

        if abs(self.vel_x) <= 0.1:
            self.state = "idle"
            self.vel_x = 0.0
        else:
            self.state = "run"

    # ========================================================
    # ANIMATE
    # ========================================================

    def _animate(self):
        side = "r" if self.facing_right else "l"

        if self.state == "idle":
            self.frame_idx = 0
            self.anim_timer = 0
            self._current_frame = self.idle_r if self.facing_right else self.idle_l
            self.image = self._current_frame
            return

        key = f"{self.state}_{side}"
        if key not in self.anim:
            key = f"run_{side}"
        frames = self.anim[key]

        if len(frames) == 1:
            self.frame_idx = 0
            self._current_frame = frames[0]
            self.image = self._current_frame
            return

        self.anim_timer += 1
        if self.anim_timer >= ANIM_SPEED:
            self.anim_timer = 0
            self.frame_idx = (self.frame_idx + 1) % len(frames)

        self._current_frame = frames[self.frame_idx]
        self.image = self._current_frame

    # ========================================================
    # DRAW POS
    # ========================================================

    def get_draw_pos(self):
        img = self._current_frame
        iw, ih = img.get_size()
        draw_x = self.rect.centerx - iw // 2
        draw_y = self.rect.bottom - ih
        return img, draw_x, draw_y

    # ========================================================
    # BLINK DAMAGE
    # ========================================================

    def should_draw(self):
        return (self.iframes == 0 or (self.iframes // 6) % 2 == 0)

    # ========================================================
    # FESTEJO
    # ========================================================

    def celebrate_kill(self, enemy_rect):
        self.celebrating = True
        self.celebrate_timer = self.CELEBRATE_DUR
        self.frame_idx = 0
        self.anim_timer = 0
        self.kill_text = random.choice(KILL_PHRASES)
        self.kill_text_timer = 80

    def _tick_celebrate(self):
        self.celebrate_timer -= 1
        if self.celebrate_timer <= 0:
            self.celebrating = False
            self.frame_idx = 0

    # ========================================================
    # SHOOT
    # ========================================================

    def can_shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot >= PROJ_COOLDOWN:
            self.last_shot = now
            self.shoot_anim_timer = 10  # 10 frames de animación de disparo
            return True
        return False

    # ========================================================
    # DAMAGE
    # ========================================================

    def take_damage(self, amount):
        if self.iframes > 0:
            return False
        self.hp -= amount
        self.iframes = PLAYER_IFRAMES
        if self.hp <= 0:
            self.hp = 0
            self.alive = False
        return True

    # ========================================================
    # SCORE
    # ========================================================

    def add_score(self, points):
        self.score += points
