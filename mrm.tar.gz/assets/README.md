# Corporate Chaos — README

## Cómo ejecutar

```bash
pip install pygame
cd mi_juego
python main.py
```

## Controles

| Tecla         | Acción              |
|---------------|---------------------|
| A / ←         | Mover izquierda     |
| D / →         | Mover derecha       |
| W / ↑ / SPACE | Saltar              |
| F / Z         | Disparar (parábola) |
| ESC           | Salir               |

## Estructura del proyecto

```
mi_juego/
├── main.py          ← Loop principal + fondo parallax
├── settings.py      ← Todas las constantes (editar aquí)
├── player.py        ← Jugador con física arcade Mario
├── enemy.py         ← Enemy (patrullaje) + BossEnemy (Mr. Grimes)
├── projectile.py    ← Proyectil parabólico + texto flotante de daño
├── level.py         ← Mapa, plataformas, spawn de enemigos, checkpoints
├── camera.py        ← Cámara suave con soporte parallax
└── ui.py            ← HUD: HP jugador, barra boss, mensajes
```

## Próximo paso: integrar los sprites de imagen

### 1. Remover fondo del player (fondo turquesa)
```python
# En player.py, reemplazar _draw_placeholder():
self.image = pygame.image.load("assets/sprites/pj.jfif").convert_alpha()
self.image = pygame.transform.scale(self.image, (50, 80))
self.image.set_colorkey((0, 200, 200))  # ajustar el turquesa exacto
```

### 2. Remover fondo del enemy (checker gris)
```python
# En enemy.py:
self.image = pygame.image.load("assets/sprites/enemy.jfif").convert_alpha()
# El checker gris (transparencia) ya debería ser transparente en PNG
```

### 3. Cargar background como imagen real
```python
# En main.py, en ParallaxBackground:
self.bg_city = pygame.image.load("assets/sprites/background.png").convert()
self.bg_city = pygame.transform.scale(self.bg_city, (WORLD_WIDTH, SCREEN_HEIGHT))
```

### 4. Convertir .jfif a .png con fondo transparente
```bash
# Con PIL (pillow):
pip install pillow
python -c "
from PIL import Image
img = Image.open('pj.jfif').convert('RGBA')
# Remover color turquesa
data = img.getdata()
new = [(0,0,0,0) if (r > 150 and g > 180 and b > 150) else (r,g,b,a)
       for r,g,b,a in data]
img.putdata(new)
img.save('player.png')
"
```

## Ajustar la física en settings.py

Si el juego se siente lento/rápido, modificar estas constantes:
- `PLAYER_ACCEL`: más alto = arranca más brusco
- `PLAYER_FRICTION`: más negativo = frena más rápido
- `PLAYER_JUMP_FORCE`: más negativo = salta más alto
- `GRAVITY_FALL_MULT`: más alto = cae más pesado (arcade feel)
