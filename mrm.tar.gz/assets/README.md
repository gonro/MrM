# MRM — Corporate Chaos
## Desarrollado por ONIRAI

---

## ESTRUCTURA DE ARCHIVOS

Tu proyecto tiene que quedar así antes de compilar:

```
mrm/
├── main.py
├── index.html          ← reemplazar el tuyo por este
├── favicon.png
├── assets/
│   ├── sprites/
│   │   ├── pj0.png
│   │   ├── pjmove.png
│   │   ├── pjfest.png
│   │   ├── quietoa.png
│   │   ├── logo_mrm.png
│   │   ├── piso.png
│   │   ├── bloque.png
│   │   ├── youwin.png
│   │   └── ... (todos los sprites)
│   ├── backgrounds/
│   │   ├── bg_street.png
│   │   ├── bg_ramen.png
│   │   └── bg_tower.png
│   ├── fonts/
│   │   └── ArcadeClassic.ttf
│   └── audio/
│       ├── level_music.ogg
│       ├── boss_music.ogg
│       ├── shoot.ogg
│       └── ... (todos los audios)
├── camera.py
├── level.py
├── player.py
├── projectile.py
├── settings.py
├── sprite_loader.py
├── ui.py
└── enemy.py            ← necesario (lo tenés vos)
```

---

## COMPILAR CON PYGBAG

### 1. Instalar pygbag (una sola vez)

```bash
pip install pygbag
```

### 2. Compilar

Desde la carpeta PADRE de tu proyecto (no dentro de mrm/):

```bash
pygbag mrm
```

Pygbag va a:
- Levantar un servidor local en http://localhost:8000
- Abrir el juego en el navegador para probar
- Generar mrm.tar.gz (el archivo que sube a GitHub Pages)

### 3. Reemplazar el index.html generado

Pygbag genera su propio index.html. Tenés que reemplazarlo
con el nuestro DESPUÉS de compilar:

```bash
# Pygbag pone los archivos en build/web/
cp index.html build/web/index.html
```

O en algunos casos directamente en mrm/:
```bash
cp index.html mrm/index.html
```

### 4. Subir a GitHub Pages

```bash
# Copiar build a tu rama gh-pages
cp -r build/web/* docs/        # o la carpeta que uses para gh-pages
git add .
git commit -m "deploy"
git push
```

---

## CAMBIOS EN ESTA VERSIÓN

### main.py
- IS_MOBILE detecta si es celular (emscripten) o PC automáticamente
- Botones táctiles SOLO aparecen en celular, en PC no se ven
- Fix botones que quedaban "apretados": FINGERUP resetea TODOS los
  botones sin importar la posición del dedo al soltar
- Múltiples dedos simultáneos funcionan (izq + saltar, der + disparar)
- Mensaje en intro y game over adaptado al dispositivo
- Créditos ONIRAI en intro, game over y footer del loader

### index.html
- Pantalla de carga negra profesional con spinner y anillo
- "Estás jugando la versión Demo / Próximamente versión completa"
- Logos de iOS, Windows y Android
- "Desarrollado por ONIRAI" al pie
- Overlay iOS con instrucciones para agregar a pantalla de inicio
- Fullscreen automático en primer toque/click
- Fix altura Safari iOS
